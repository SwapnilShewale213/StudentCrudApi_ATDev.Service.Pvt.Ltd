package com.crudApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/*
 * Developed @Swapnil_Shewale
 * 19 April 2022
 */

@SpringBootApplication
public class CrudApiAtDevServicePvtLtdApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApiAtDevServicePvtLtdApplication.class, args);
		
		System.out.println("Hello Welcome to Spring Boot Framework");
	}

}
		