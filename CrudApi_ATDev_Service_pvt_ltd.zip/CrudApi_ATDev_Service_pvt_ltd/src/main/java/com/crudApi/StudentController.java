package com.crudApi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.crudApi.entity.Student;
import com.crudApi.service.StudentService;


/*
 * Developed by @Swapnil_Shewale
 * 20 April 2022
 * 
 */

@RestController
public class StudentController {
	
	@Autowired(required = true)
	 private StudentService studentService;
	
	@GetMapping("/students")
	@ResponseBody
	public ResponseEntity<List<Student>> getAllStudent(){
		
		return ResponseEntity.ok().body(studentService.getAllStudents());
	}
	
	@RequestMapping( value = "/students/{studentId}" , method = RequestMethod.GET ,consumes = {"application/json" , "application/xml"})
	public ResponseEntity<Student> getStudentById(@PathVariable String studentId){
		    
		//student.setStudentId(studentId);
		return ResponseEntity.ok().body(studentService.getStudentById(studentId));
	}
	
	@PostMapping( value = "/students" , consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Student> addStudent( @RequestBody Student student) {
		
		return ResponseEntity.ok().body(studentService.addStudent(student));
		
	}
    @RequestMapping(value = "/students/{studentId}" ,method = RequestMethod.PUT , consumes =MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
	public ResponseEntity<Student> updateStudent( @RequestBody Student student , 
			           @PathVariable String studentId){
		student.setStudentId(studentId);
		return ResponseEntity.ok().body(studentService.addStudent(student));
	}
    
    @RequestMapping( value = "/students/{studentId}" , method = RequestMethod.DELETE )
    public void deleteStudentById(@PathVariable String studentId) {
    	
    	studentService.deleteStudentById(studentId);
    	
    }
	
}
