package com.crudApi.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;

/*
 * developed by Swapnil Shewale
 * 19 April 2022
 * 
 */

@Entity
@Transactional
@Table(name = "studentDb")
public class Student {
	 
	
	public Student() {
		
	}
	
	 public Student(String studentId, String studentName, String address, String college, Long mobile) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		Address = address;
		College = college;
		this.mobile = mobile;
	}
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name="studentId")
	 private String studentId;
	 
	@Column(name = "studentname")
	 private String studentName;
	 
	 @Column(name = "address")
	 private String Address;
	 
	 @Column(name = "college")
	 private String College;
	 
	 @Column(name = "mobile")
	 private Long mobile;

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getCollege() {
		return College;
	}

	public void setCollege(String college) {
		College = college;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	 

}
