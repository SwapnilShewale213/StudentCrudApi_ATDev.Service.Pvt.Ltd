package com.crudApi.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crudApi.entity.Student;
import com.crudApi.repository.StudentRepository;

@Service
@Transactional
public class StudentService {
	
	@Autowired
	StudentRepository studentRepository;

	public List<Student> getAllStudents(){
		
		return  studentRepository.findAll();
	}
	
	public Student getStudentById(String studentId) {
		
		return studentRepository.getById(studentId);
	}
	
	public Student addStudent(Student student) {
		
		return studentRepository.save(student);
	}
	
	public Student upStudent(Student student) {
		
		return studentRepository.save(student);
	}
	
	public void deleteStudentById(String studentId) {
		
		studentRepository.deleteById(studentId);
	}
	
	

}
