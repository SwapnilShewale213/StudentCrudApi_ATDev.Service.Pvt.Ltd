package com.crudApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudApiAtDevServicePvtLtdApplicationTests {

	@Test
	void contextLoads() {
	}

}
